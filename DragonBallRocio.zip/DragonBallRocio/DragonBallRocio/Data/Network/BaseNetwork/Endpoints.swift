//
//  Endpoints.swift
//  DragonBallRocio
//
//  Created by Rocio Martos on 17/3/24.
//

import Foundation
enum Endpoints: String{
    case login = "/auth/login"
    case heros = "/heros/all"
    case transformation = "/heros/tranformations"
}
