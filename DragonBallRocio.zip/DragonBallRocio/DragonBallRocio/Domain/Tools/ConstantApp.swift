//
//  ConstantApp.swift
//  DragonBallRocio
//
//  Created by Rocio Martos on 17/3/24.
//

import Foundation

struct ConstantApp{
    static let CONST_API_URL = "https://dragonball.keepcoding.education/api"
    static let CONST_TOKEN_ID_KEYCHAIN = "tokenJWTKeyChaincom.keepcoding.proyecto"

}
