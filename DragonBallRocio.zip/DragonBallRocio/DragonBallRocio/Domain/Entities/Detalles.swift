//
//  Detalles.swift
//  DragonBallRocio
//
//  Created by Rocio Martos on 20/3/24.
//

import Foundation
struct Detalles: Codable{
    var heroID: String
    var name: String
    var descripcion: String
    var photo: String
}
